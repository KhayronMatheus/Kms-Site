import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Instagram, Phone } from "lucide-react";
import { motion } from "framer-motion";

export default function Home() {
  return (
    <main className="bg-white text-blue-900">
      {/* Header */}
      <header className="flex flex-wrap justify-between items-center p-4 shadow-md bg-blue-100">
        <img src="/logo.jpg" alt="KMS Logo" className="h-12" />
        <nav className="flex flex-wrap gap-4 text-sm">
          <a href="#sobre">Quem Somos</a>
          <a href="#solucoes">Soluções</a>
          <a href="#depoimentos">Depoimentos</a>
          <a href="#contato">Contato</a>
        </nav>
      </header>

      {/* Hero Section */}
      <section className="bg-gradient-to-r from-blue-900 to-blue-500 text-white p-12 text-center relative">
        <motion.h1 className="text-4xl font-bold mb-4">
          SEGURANÇA FINANCEIRA COM QUEM ENTENDE DE GENTE
        </motion.h1>
        <p className="text-lg mb-6">
          Empréstimos, crédito pessoal e consórcio com confiança, transparência e agilidade.
        </p>
      </section>

      {/* Botões Centrais */}
      <section className="text-center bg-blue-50 py-6">
        <div className="flex justify-center gap-4 flex-wrap">
          <a href="https://wa.me/558896841333" target="_blank" rel="noopener noreferrer">
            <Button className="bg-white text-blue-900 font-semibold hover:bg-blue-100">
              <Phone className="h-4 w-4 mr-1" /> WhatsApp
            </Button>
          </a>
          <a href="https://instagram.com/kms_emprestimos" target="_blank" rel="noopener noreferrer">
            <Button className="bg-white text-blue-900 font-semibold hover:bg-blue-100">
              <Instagram className="h-4 w-4 mr-1" /> Instagram
            </Button>
          </a>
        </div>
      </section>

      {/* Sobre Nós */}
      <section id="sobre" className="p-12 bg-white text-center">
        <h2 className="text-2xl font-bold text-blue-800 mb-4">Quem Somos</h2>
        <p className="max-w-3xl mx-auto text-blue-900">
          A KMS nasceu no coração de Deus, com o propósito de representar a família, a integridade e a segurança. Aqui, o compromisso vai além do crédito — entregamos tranquilidade, respeito e soluções reais.
        </p>
      </section>

      {/* Diretora */}
      <section className="p-12 bg-blue-50 text-center">
        <h2 className="text-2xl font-bold text-blue-800 mb-6">Ederlane – Diretora Geral</h2>
        <div className="flex flex-col md:flex-row items-center justify-center gap-6">
          <img src="/gerente.jpg" alt="Ederlane – Diretora Geral" className="w-64 rounded-xl shadow-lg" />
          <p className="max-w-2xl text-blue-800 mt-4 md:mt-0 text-left">
            Com mais de 10 anos de experiência, Ederlane é o coração da KMS. Diretora Geral com mais de 10 anos de experiência, sua trajetória de superação inspira toda a equipe. Com fé, resiliência e propósito, ela começou atendendo para sustentar o filho e hoje lidera com princípios sólidos, humanidade e visão estratégica. Deus e a família são os pilares de sua liderança. Sua história de superação, fé e dedicação à família reflete em cada atendimento feito com empatia e verdade.
          </p>
        </div>
      </section>

      {/* Soluções */}
      <section id="solucoes" className="p-12 bg-white">
        <h2 className="text-2xl font-bold text-blue-800 text-center mb-6">Nossas Soluções</h2>
        <div className="grid md:grid-cols-3 gap-6">
          <Card>
            <CardContent className="p-6">
              <h3 className="font-semibold text-lg text-blue-900 mb-2">Empréstimo Consignado</h3>
              <ul className="text-blue-800 text-sm list-disc pl-4">
                <li>Sem consulta ao SPC/Serasa</li>
                <li>Parcelas na folha</li>
                <li>Taxas reduzidas</li>
              </ul>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <h3 className="font-semibold text-lg text-blue-900 mb-2">Crédito Pessoal</h3>
              <ul className="text-blue-800 text-sm list-disc pl-4">
                <li>Aprovação facilitada</li>
                <li>Liberação rápida</li>
              </ul>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <h3 className="font-semibold text-lg text-blue-900 mb-2">Consórcio</h3>
              <ul className="text-blue-800 text-sm list-disc pl-4">
                <li>Para imóveis, carros ou motos</li>
                <li>Planejado e sem juros abusivos</li>
              </ul>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Depoimentos */}
      <section id="depoimentos" className="p-12 bg-blue-50 text-center">
        <h2 className="text-2xl font-bold text-blue-800 mb-6">O que nossos clientes dizem</h2>
        <div className="grid md:grid-cols-2 gap-6 max-w-4xl mx-auto">
          <Card>
            <CardContent className="p-6 text-left">
              <p className="text-blue-900">"A KMS me tratou como gente. Saí com o empréstimo aprovado e o coração tranquilo!"</p>
              <p className="text-sm text-blue-700 mt-2">– Maria das Dores, aposentada</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6 text-left">
              <p className="text-blue-900">"Tudo feito com transparência. Atendimento nota mil!"</p>
              <p className="text-sm text-blue-700 mt-2">– João Batista, servidor público</p>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Contato + Botão final */}
      <section id="contato" className="p-12 bg-white text-center">
        <h2 className="text-2xl font-bold text-blue-800 mb-6">Fale com a gente</h2>
        <p className="text-blue-900 mb-4">📍 Russas – CE</p>
        <p className="text-blue-900 mb-2">📞 WhatsApp: (88) 9 9684-1333</p>
        <p className="text-blue-900 mb-6">📷 Instagram: @kms_emprestimos</p>
        <a href="https://wa.me/558896841333" target="_blank" rel="noopener noreferrer">
          <Button className="bg-blue-900 text-white font-semibold hover:bg-blue-800">
            Fale com um especialista agora
          </Button>
        </a>
      </section>

      {/* Footer */}
      <footer className="bg-blue-900 text-white text-center p-6 text-sm">
        <img src="/logo.jpg" alt="KMS Logo" className="h-10 mx-auto mb-2" />
        <p>“Criar com foco em compromisso e integridade.”</p>
        <p>CNPJ: 38.043.697/0001-50</p>
        <p className="mt-2">© {new Date().getFullYear()} KMS Empréstimos e Soluções. Todos os direitos reservados.</p>
      </footer>
    </main>
  );
}
